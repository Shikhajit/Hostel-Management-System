package com.metacube.hotselmanagement.date;


import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class GetCurrentDateTime {

	public String mainn(){
		// TODO Auto-generated method stub
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		   //get current date time with Date()
		   Date date = new Date();
		   System.out.println(dateFormat.format(date));
		   
		 //get current date time with Calendar()
		   Calendar cal = Calendar.getInstance();
		   String datee = dateFormat.format(cal.getTime());
		   System.out.println(dateFormat.format(cal.getTime()));
		return datee;  
	}
}		 
	
		        
		       
		   

	

