package com.metacube.hostelmanagement.vo;

public class ComplaintVO {
	private String complaint;
	private String username;
	
	public String getComplaint(){
		return complaint;
		}

	public void setComplaint(String complaint) {
		this.complaint = complaint;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
}
