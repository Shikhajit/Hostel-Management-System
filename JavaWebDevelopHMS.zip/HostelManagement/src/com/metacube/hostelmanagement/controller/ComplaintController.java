package com.metacube.hostelmanagement.controller;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.metacube.hostelmanagement.facade.LoginFacade;
import com.metacube.hostelmanagement.vo.ComplaintVO;;

/**
 * Servlet implementation class signupController
 */
public class ComplaintController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("Complaints.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ComplaintVO complaintVO = new ComplaintVO();
		response.setContentType("text/html;charset=UTF-8");

		String username = request.getParameter("username");
		String complaint = request.getParameter("complaint");

		if(complaint=="") {
			request.setAttribute("message", "Please write , it can't take null ");
			request.getRequestDispatcher("Complaints.jsp").forward(request,
					response);
			System.out.println("Writing text COMPULSARY required to submit");
		} 
		
		else {
			
			complaintVO.setComplaint(complaint);
			complaintVO.setComplaint(username);
			
						
			LoginFacade loginFacade = new LoginFacade();
			boolean authenticated = loginFacade.authenticate(complaintVO);
			
			if (authenticated==true) {
			
				try{
					System.out.println("begin Complaints !"+username);
					Class.forName("com.mysql.jdbc.Driver");
						
					// 1. Get a connection
						Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","oracle");
					
					
			        // 2.Execute Query & Process the result set 
					 String updateString ="INSERT INTO demo.complaints (user,complaints) VALUES (?,?)";

					        PreparedStatement preparedStatement = myConn.prepareStatement(updateString);
					       
					        preparedStatement.setString(1, username);
					        preparedStatement.setString(2, complaint);
					       
					        int i = preparedStatement.executeUpdate();
					
						if(i>0)
						{
						  System.out.println("Your Complaint is registered");
						}
					}
							catch (Exception exc){
								exc.printStackTrace();
							}

				
				request.setAttribute("message", "Welcome " + username);
				request.getRequestDispatcher("ComplainView.jsp").forward(request,
						response);
			} else {
				request.setAttribute("message","User with this Username does not exist");
				request.getRequestDispatcher("Complaints.jsp").forward(request,response);
			}
		}
	}

}
