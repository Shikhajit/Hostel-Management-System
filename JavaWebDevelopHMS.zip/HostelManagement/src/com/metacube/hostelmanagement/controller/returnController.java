package com.metacube.hostelmanagement.controller;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.metacube.hotselmanagement.date.GetCurrentDateTime;


/**
 * Servlet implementation class signupController
 */
public class returnController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("SignUp.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");

		GetCurrentDateTime gcdt = new GetCurrentDateTime();
		
		String username = request.getParameter("username");
		String rdate = gcdt.mainn();
		String book_name = request.getParameter("book_name");
		
		
		if ((username=="")|| (book_name.equals(""))) {
			request.setAttribute("message", "Please FILL all the details");
			request.getRequestDispatcher("SignUp.jsp").forward(request,
					response);
			System.out.println("All Fields are COMPULSARY !!");
		} 
			
		
				try{
					System.out.println("Welcome !"+username);
					Class.forName("com.mysql.jdbc.Driver");
					
					Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","oracle");
					 String updateString ="update demo.library SET rdate='"+rdate+"' where user ='" +username + "' AND bookname ='" +book_name + "' ";

				        PreparedStatement preparedStatement = myConn.prepareStatement(updateString);
				       
				       
				        int i = preparedStatement.executeUpdate();
				
					if(i>0)
					{
					  System.out.println("You have successfully returned");
					}
				}
				
				catch(Exception se)
				{
				  se.printStackTrace();
				}
				
				request.setAttribute("message", "Welcome  " + username+ " your book " +book_name+ " is returned");
				request.getRequestDispatcher("Booksinfo.jsp").forward(request,
						response);
			
		}
	}

