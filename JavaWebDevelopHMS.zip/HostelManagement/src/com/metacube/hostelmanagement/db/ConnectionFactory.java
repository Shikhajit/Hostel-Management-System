package com.metacube.hostelmanagement.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {

	
	public static Connection getConnection() {
			
		Connection connection = null;
		
		return connection;
	}
	
	
}
