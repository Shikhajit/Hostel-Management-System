package com.metacube.hostelmanagement.db.dao;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
//import com.metacube.hostelmanagement.db.ConnectionFactory;
import com.metacube.hostelmanagement.vo.LoginVO;
import com.metacube.hostelmanagement.vo.SignupVO;


public class LoginDAO {
	
	
	public LoginVO getLoginByUsername(String username) {		
		
		String usern;
		LoginVO loginVO = null;
		
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			// 1. Get a connection
			Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","oracle");
		
			// 2. Create a Statement
			Statement myStmt = myConn.createStatement();
			
            // 3.Execute Query & Process the result set 
			ResultSet rs = myStmt.executeQuery("select * from demo.login where user='" + username + "'");
          
            if (rs.next()) {
				loginVO = new LoginVO();
            	
            	usern = rs.getString("user");
            	loginVO.setUsername(usern);
            	
            	System.out.println("correct login credentials");
            	loginVO.setPassword(rs.getString("pass"));
             } 
            else {
                System.out.println("Incorrect login credentials");
            	}
		}

		catch (Exception exc){
			exc.printStackTrace();
		}
		return loginVO;
	}
	
	
	public SignupVO getSignupByUserCheck(String username) {
		
		SignupVO signupVO = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			
			Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","oracle");
		
			Statement myStmt = myConn.createStatement();
			
			ResultSet rs = myStmt.executeQuery("select * from demo.login where user='" + username + "'");
			
			while(rs.next()) {
				
				signupVO = new SignupVO();
				
				signupVO.setUsername(rs.getString("user"));
				signupVO.setPassword(rs.getString("pass"));
				signupVO.setRollNo(rs.getString("rollNo"));
				signupVO.setRoomNo(rs.getString("roomNo"));
				signupVO.setPhoneNo(rs.getString("phoneNo"));
				signupVO.setYear(rs.getString("year"));
				signupVO.setBranch(rs.getString("branch"));
				signupVO.setImage(rs.getString("image"));
				
				System.out.println("Duplicate/Repeated username NOT ALLOWED");
				
			}
		rs.close();
			myConn.close();
			
			}
			catch(Exception se)
			{
			  se.printStackTrace();
			}
		return signupVO;
	}		
}
