package com.metacube.hostelmanagement.db.dao;
import java.sql.*;

import com.metacube.hostelmanagement.vo.ComplaintVO;

public class ComplaintsDAO {

	public ComplaintVO getCheck(String username) {
		
		ComplaintVO complaintVO=null;
			try{
			Class.forName("com.mysql.jdbc.Driver");
			// 1. Get a connection
			Connection myConn=DriverManager.getConnection("jdbc:mysql://localhost:3306/demo","root","oracle");
		
			// 2. Create a Statement
			Statement myStmt = myConn.createStatement();
			
			ResultSet rs = myStmt.executeQuery("select * from demo.login where user='" + username + "'");
	          
            while (rs.next()) {
				complaintVO = new ComplaintVO();
            	
            	complaintVO.setUsername(rs.getString("user"));
            	
            	System.out.println("correct username, user exists");
            	//complaintVO.setComplaint(rs.getString("p"));
             } 
            rs.close();
			myConn.close();
			
			}
			
            catch (Exception exc){
    			exc.printStackTrace();
    		}
    		return complaintVO;
			
		}
	}

